Author: Emanuel Navarro Programmer
Email: emannavarro@gmail.com
Projects Partner: Rajan Silwal
OS: Windows
Asn#: A12
Status: Completed
Files:
electionfile.cpp assignment built on last three weeks plus extra credit

filelist.cpp inclasswork

filework.cpp assignment learning how to work with files

helper.cpp part of electionfile

productapp.cpp inclass work

readwrite.cpp in class work

rectangles.cpp in class work

testy.cpp inclass testing of code by Manny

candidate.tx part of electionfile

infile.txt part turn in assignments

ints.txt part turn in assignments

names.txt part turn in assignment

product.txt part of in class work

product2.txt part of in class work

rawdata.txt part of in class work

report.txt part of electionfile

strs.txt part of the turn in assignment

README.txt part of the HW

Hours on Lab Exercises:10
Hours Working With Partner: 2
Hours Working Alone: 10
Extra Credit:0.5
Hours Total: 22.5
-Completed program following pair-programming guidelines
