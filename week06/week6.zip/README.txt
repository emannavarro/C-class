Author: Emanuel Navarro Programmer
Email: emannavarro@gmail.com
Projects Partner: Silwal
OS: Windows
Asn#: A5 && A6
Status: Completed
Files:
countdown.cpp -counts down from 10 down to zero
counting.cpp -counts in a list numbers
findword.cpp -finds word in the statement
forloop.cpp - lists out lumbers
loopwork.cpp -loop worsheet
realfake.cpp - tells whether a newsite is real or fake
scores - keep a score of numbers
test.cpp - test what array number is in each box
vote.cpp - tallys votes
extra credit with realfake.cpp news adding the extra cout stating which site is real and which is fake
README.txt
Hours on Lab Exercises: 10
Hours Working With Partner: 3
Hours Working Alone: 20
Extra Credit:2
Hours Total: 25
-Completed program following pair-programming guidelines
