Author: Emanuel Navarro Programmer
Email: emannavarro@gmail.com
Projects Partner: Rajan Silwal
OS: Windows
Asn#: A11
Status: Completed
Files:
babynames.cpp- list of babynamestaken from a file
cat.cpp- inclasswork
copytwo.cpp-inclasswork
elections.cpp-improved candidate
learn.cpp-inclass work
namelist.cpp-inclass work
provector.cpp-inclass work
starter.cpp-inclass work
vectorwork.cpp-hw assignment
xvectorwork.cpp- extra credit


Hours on Lab Exercises:5
Hours Working With Partner: 2
Hours Working Alone: 5
Extra Credit:3
Hours Total: 15
-Completed program following pair-programming guidelines
