/**
    CS-11 learn.cpp
    Purpose:inclass work

    @author Emanuel Navarro
    @version 11/13/18
*/

#include <iostream>
#include <vector>
using namespace std;



int main() {


    vector<int> v(3);
    const int A3 = 3, A9 = 9;
    vector<int> data4 = {1, A9, 2, 3};


    for( unsigned i=0; i<data4.size(); i++) {

        cout<< data4[i]<< endl;

    }







    return 0;


}