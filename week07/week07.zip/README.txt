Author: Emanuel Navarro Programmer
Email: emannavarro@gmail.com
Projects Partner: Rajan Silwal
OS: Windows
Asn#: A7
Status: Completed
Files:
dice.cpp- creates a program that generates dice values
funwor.cpp- created multiple functions to test out values
myarrays.cpp- initializes arrays and tests them out
passwords.cpp- Generates a more secure password
sub.cpp- created a function to subract to values
test.cpp- tests out arrays for inclass
trace.cpp- trace of a program inclass
wisdom-This block of code chooses a value at random from the array startpharses and concatenates it with with another value
from the array endphrases
xcfunwork- extra credit that silwal and I created to find the value of lime
password.exe.stackdump- my program took a dump on me...
README.txt- notes on all the programs in this zip file


Hours on Lab Exercises: 2
Hours Working With Partner: 5
Hours Working Alone: 10
Extra Credit:3
Hours Total: 20
-Completed program following pair-programming guidelines
