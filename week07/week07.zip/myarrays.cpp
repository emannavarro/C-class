/**
    CS-11 Asn 7, myarrays.cpp
    Purpose: initializing arrays

    @author Emanuel Navarro
    @version 10/15/18
*/





/*
Linear Search Algorithm
... write the algorithm here

initialize the array
parse throught the array
for( int x=0;, x<n; x++)
    parse throught it
*/

#include <iostream>
using namespace std;

int main()
{
    // Enter your code here


    double temp[] = { 1.2, 1.3, 1.4, 1.5, 1.6 };
    int LENGTH=5;
    for (int i=0; i< LENGTH; i++)

        cout << temp[i] << endl;

    return 0;
}