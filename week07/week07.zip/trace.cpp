/**
    CS-11 Asn 7, trace.cpp
    Purpose: traces program in class

    @author Emanuel Navarro
    @version 10/15/18
*/

9
10
11
12
4
5
6
13
14
15
16

