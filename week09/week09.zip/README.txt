Author: Emanuel Navarro Programmer
Email: emannavarro@gmail.com
Projects Partner: Rajan Silwal
OS: Windows
Asn#: A9
Status: Completed
Files:
candidate.cpp - creates objects and classes( extra credit w silwal)
parrot.cpp Creates classes (extra credit w silwal)
car.cpp-in class assignment 
coffee.cpp-inclass assignment

Hours on Lab Exercises: 3
Hours Working With Partner: 2
Hours Working Alone: 8
Extra Credit:2
Hours Total: 15
-Completed program following pair-programming guidelines
