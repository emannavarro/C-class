Author: Emanuel Navarro Programmer
Email: emannavarro@gmail.com
Projects Partner: Rajan Silwal
OS: Windows
Asn#: A8
Status: Completed
Files:
Funwork2.cpp uses our knowledge to create functions
mealfun.cpp creates a program calculating price and tip while rejecting unwanted values
pizza.cpp- created in class with Abby, James, Rajwan and I
squares.cpp- in class program used for squaring
swap.cpp swaps values and show us what passing a value of a variable
trace.txt trace of in class program
extra credit used setw and setprecision  
README.txt- notes on all the programs in this zip file


Hours on Lab Exercises: 3
Hours Working With Partner: 2
Hours Working Alone: 8
Extra Credit:1
Hours Total: 14
-Completed program following pair-programming guidelines
